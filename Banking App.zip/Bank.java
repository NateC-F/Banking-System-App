import personlib.Person;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class Bank
{
    private ArrayList<BankAccount> bankAccounts=null;

    public Bank()
    {
        bankAccounts = new ArrayList<BankAccount>();
    }

    public Bank(ArrayList<BankAccount> initBankAccounts)
    {
        bankAccounts = new ArrayList<BankAccount>();
    }

    public void addAccount(BankAccount accountToAdd)
    {
        bankAccounts.add(accountToAdd);
    }

    public BankAccount findAccount(int accountNumber)
    {
        BankAccount accountFound=null;
        for(int pos=0;pos<bankAccounts.size();pos++)
        {
            BankAccount curAccount=bankAccounts.get(pos);
            if(curAccount.getAccountNumber()==accountNumber)
            {
                accountFound=curAccount;
                break;
            }
        }
        return accountFound;
    }

    public boolean deleteAccount(int accountNumber)
    {
        boolean success=true;
        BankAccount account = findAccount(accountNumber);

        if (account==null)
            success=false;
        else
        {
            bankAccounts.remove(account);
            success=true;
        }
        return success;
    }

    public double averageBalances()
    {
        double averageBalance=0.0;

        for(int pos=0;pos<bankAccounts.size();pos++)
        {
            BankAccount curAccount=bankAccounts.get(pos);
            averageBalance += curAccount.getCurrentBalance();
        }
        return (averageBalance/ bankAccounts.size());
    }

    public double largestBankAccount()
    {
        double maxBalance = Double.MIN_VALUE;
        for (int pos=0;pos<bankAccounts.size();pos++)
        {
            BankAccount curAccount = bankAccounts.get(pos);
            if (curAccount.getCurrentBalance()>maxBalance)
                maxBalance=curAccount.getCurrentBalance();
        }
        return  maxBalance;
    }

    public double smallestBankAccount()
    {
        double minBalance = Double.MAX_VALUE;
        for (int pos=0;pos<bankAccounts.size();pos++)
        {
            BankAccount curAccount = bankAccounts.get(pos);
            if (curAccount.getCurrentBalance()<minBalance)
                minBalance=curAccount.getCurrentBalance();
        }
        return  minBalance;
    }

    public ArrayList<BankAccount> getLowBalanceAccounts(double balanceThreshold)
    {
        ArrayList<BankAccount> lessThanAccounts = new ArrayList<BankAccount>();

        for (int pos=0;pos<bankAccounts.size();pos++)
        {
            BankAccount curAccount = bankAccounts.get(pos);
            if (curAccount.getCurrentBalance()<balanceThreshold)
                lessThanAccounts.add(curAccount);
        }
        return lessThanAccounts;
    }

    public int createID()
    {
        boolean original = false;
        int newID = 0;

        while (!original)
        {
            int idCheck=(int) (1000 * Math.random()) + 1;
            for (int pos = 0; pos < bankAccounts.size(); pos++)
            {
                BankAccount curAccount = bankAccounts.get(pos);
                if (curAccount.getAccountNumber() != idCheck)
                {
                    original=true;
                    newID=idCheck;
                }
                if (original)
                    break;
            }
        }
        return newID;
    }

    public void finalSave(String filePath) throws Exception
    {
        FileOutputStream fos = new FileOutputStream(filePath);
        OutputStreamWriter osw = new OutputStreamWriter(fos);

        for (int pos=0;pos<bankAccounts.size();pos++)
        {
            osw.write(bankAccounts.get(pos).convertToText());
        }

        osw.close();
        fos.close();
    }

    public void load(String filePath)throws Exception
    {
        FileInputStream fis = new FileInputStream(filePath);
        Scanner fileScanner = new Scanner(fis);

        String storedInfo="";
        while(fileScanner.hasNextLine())
        {
            String textLine = fileScanner.nextLine();
            if(!textLine.equals("New Account"))
                storedInfo+=(textLine+"\n");
            else
            {
                BankAccount accountsAdded = new BankAccount();
                accountsAdded.loadFromText(storedInfo);
                bankAccounts.add(accountsAdded);
                storedInfo="";
            }
        }
    }

}
