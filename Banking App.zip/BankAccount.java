import personlib.Person;

import java.util.Scanner;

public class BankAccount
{
    private int accountNumber;
    private String dateCreated;

    private double curBalance;
    private double withdrawLimit;
    private double curWithdrawLimit;
    private Person accountHolder;
    private int accountType;

    private int timesDeposited;

    private int timesWithdrawn;

    public BankAccount(Person initAccountHolder, double initWithdrawLimit,
                       double initBalance, String initDateCreated, int initAccountNumber)
    {
        accountHolder=initAccountHolder;
        withdrawLimit = initWithdrawLimit;
        curBalance = initBalance;
        dateCreated = initDateCreated;
        accountNumber = initAccountNumber;
        curWithdrawLimit = withdrawLimit;
    }

    public BankAccount()
    {

    }

    public int withdrawFunds(double withdrawAmount)
    {
        int success=0;
        if (withdrawAmount > curWithdrawLimit)
            success=1;
        if (curBalance - withdrawAmount<0)
            success=2;
        if (success==0)
        {
            curBalance -= withdrawAmount;
            curWithdrawLimit -= withdrawAmount;
        }
        return success;
    }

    public void depositMoney (double depositAmount)
    {
      if (depositAmount>0)
          curBalance += depositAmount;
    }

    public String getAccountHolderInfo(String Address, String PhoneNumber)
    {
        String accountInfo=accountHolder.getName() + ", is the owner of account " +accountNumber+ ", you can call them at "
                +accountHolder.getPhoneNumber() +", or send a letter to this address,"
                +accountHolder.getAddress()+'.';
        return accountInfo;
    }

    public double checkFunds()
    {
        return curBalance;
    }


    public int getAccountNumber()
    {
        return accountNumber;
    }
    public double getCurrentBalance()
    {
        return curBalance;
    }
    public String getDateCreated()
    {
        return dateCreated;
    }
    public double getWithdrawLimit()
    {
        return withdrawLimit;
    }
    public Person getAccountHolder() {return accountHolder;}
    public double getCurWithdrawLimit()
    {
        return curWithdrawLimit;
    }


    public void setAccountNumber(int newAccountNumber)
    {
        if (newAccountNumber>=0)
            accountNumber=newAccountNumber;
    }
    public void setCurrentBalance(double newBalance)
    {
        if (newBalance>=0)
            curBalance =newBalance;
    }
    public void setDateCreated(String newDate)
    {
        if (!newDate.isEmpty())
            dateCreated=newDate;
    }
    public void setWithdrawLimit(double newLimit)
    {
        if(newLimit>=0)
            withdrawLimit=newLimit;
    }
    public void setAccountHolder(Person newHolder)
    {
        if(newHolder!=null)
            accountHolder=newHolder;
    }
    public void setCurWithdrawLimit(Double maxWithdraw)
    {
        curWithdrawLimit=maxWithdraw;
    }
    public void setAccountType(int newType)
    {
        if(newType==1 || newType ==2)
            accountType=newType;
    }
    public int getAccountType()
    {
        return accountType;
    }


    public String toString()
    {
        String info= "The account holder information is "+accountHolder.toString()
                +", your current balance is "+ curBalance + ", your withdraw limit is "
                +withdrawLimit+", this account was created on " +dateCreated;
        return info;
    }
    public String convertToText()
    {
        String info = "";
        info += accountHolder.getName() + "\n" + accountHolder.getPhoneNumber() + "\n" + accountHolder.getAddress()+ "\n"
                + dateCreated+ "\n" +accountType + "\n"+ accountHolder.getAge() + " " + accountHolder.getGender() + " " + accountNumber + " " +
            curBalance + " " + curWithdrawLimit + "\n"+ accountType + timesWithdrawn + timesDeposited +"\nNew Account\n";

        return info;
    }

    public void loadFromText(String accToAdd)
    {
        Scanner bankScanner= new Scanner(accToAdd);
        String name = bankScanner.nextLine();
        String phoneNumber = bankScanner.nextLine();
        String address = bankScanner.nextLine();
        dateCreated = bankScanner.nextLine();
        int age = bankScanner.nextInt();
        char gender = bankScanner.next().charAt(0);
        accountNumber = bankScanner.nextInt();
        curBalance = bankScanner.nextDouble();
        withdrawLimit = bankScanner.nextDouble();
        curWithdrawLimit=withdrawLimit;
        accountHolder = new Person(name,gender,age,address,phoneNumber);
    }
    public int getTimesDeposited()
    {
        return timesDeposited;
    }
    public void setTimesDeposited(int newTimesDeposited)
    {
        if(newTimesDeposited>=0)
            timesDeposited=newTimesDeposited;
    }
    public int getTimesWithdrawn()
    {
        return timesWithdrawn;
    }
    public void setTimesWithdrawn(int newTimesWithdrawn)
    {
        if(newTimesWithdrawn>=0)
            timesWithdrawn=newTimesWithdrawn;
    }
}
