import java.net.IDN;
import java.util.ArrayList;
import java.util.Scanner;
import java.text.DecimalFormat;
import personlib.Person;


public class BankMain
{

    public static void accountMenu(BankAccount accountBeingUsed)
    {
        int choice=-1;
        Scanner scanner = new Scanner(System.in);

        SavingAccount savingAccount = null;
        CheckingAccount checkingAccount =null;

        final int CHECKING_DEPOSITS = 10;
        final double CHECKING_BONUS = .05;
        final int SAVING_DEPOSITS = 10;
        final double  SAVING_BONUS = .2;
        final double SAVING_FEE = .05;
        final int SAVING_WITHDRAWS = 3;

        int type = accountBeingUsed.getAccountType();

        if (type==1)
        {
            savingAccount = new SavingAccount(accountBeingUsed.getAccountHolder(), accountBeingUsed.getWithdrawLimit(),
                    accountBeingUsed.getCurrentBalance(), accountBeingUsed.getDateCreated(),accountBeingUsed.getAccountNumber(),
                    SAVING_FEE,SAVING_BONUS,SAVING_DEPOSITS,SAVING_WITHDRAWS, accountBeingUsed.getTimesWithdrawn(), accountBeingUsed.getTimesDeposited());
        }

        if (type==2)
        {
            checkingAccount = new CheckingAccount(accountBeingUsed.getAccountHolder(), accountBeingUsed.getWithdrawLimit(),
                    accountBeingUsed.getCurrentBalance(), accountBeingUsed.getDateCreated(),accountBeingUsed.getAccountNumber(),
                    CHECKING_BONUS,CHECKING_DEPOSITS, accountBeingUsed.getTimesDeposited());
        }

        while (choice!=4)
        {
            System.out.println("1) Deposit Money\n2) Withdraw Money\n3) Check Balance\n4) Return to main menu");
            choice = scanner.nextInt();
            switch (choice)
            {
                case 1:
                    //deposit money
                    System.out.println("How much money will you be adding? Negative Numbers will not be accepted.");
                    double deposit = scanner.nextDouble();
                    if(type == 1)
                    {
                        savingAccount.depositMoney(deposit);
                        System.out.println("New balance is " + (savingAccount).getCurrentBalance());
                    }
                    else
                    {
                        checkingAccount.depositMoney(deposit);
                        System.out.println("New balance is " + (checkingAccount).getCurrentBalance());
                    }
                    break;
                case 2:
                    //withdraw money
                    if(type==1)
                    {
                        System.out.println("How much would you like to " +
                                "withdraw, your balance is " + (savingAccount).getCurrentBalance() +
                                ", and current limit is " + (savingAccount).getCurWithdrawLimit());
                    }
                    else
                    {

                        System.out.println("How much would you like to " +
                                "withdraw, your balance is " + (checkingAccount).getCurrentBalance() +
                                ", and current limit is " + (checkingAccount).getCurWithdrawLimit());
                    }
                    double withdrawAmount = scanner.nextDouble();
                    if(type==1)
                    {
                        int success = savingAccount.withdrawFunds(withdrawAmount);
                        switch (success)
                        {
                            case 0:
                                System.out.println("Withdraw Successful!");
                                break;
                            case 2:
                                System.out.println("Withdraw failed due to not enough balance.");
                                break;
                            case 1:
                                System.out.println("Withdraw failed due to not enough withdraw limit.");
                                break;
                        }
                    }
                    else
                    {
                        int success = checkingAccount.withdrawFunds(withdrawAmount);
                        switch (success)
                        {
                            case 0:
                                System.out.println("Withdraw Successful!");
                                break;
                            case 2:
                                System.out.println("Withdraw failed due to not enough balance.");
                                break;
                            case 1:
                                System.out.println("Withdraw failed due to not enough withdraw limit.");
                                break;
                        }
                    }
                    break;
                case 3:
                    //displays balance
                    if(type==1)
                        System.out.println("Your current balance is " + (savingAccount.getCurrentBalance()));
                    else
                        System.out.println("Your current balance is " + (checkingAccount.getCurrentBalance()));
                    break;
                case 4:
                    //quits to main menu
                    System.out.println("Returning to main menu");
                    if (type==1)
                        accountBeingUsed = savingAccount;
                    if (type==2)
                        accountBeingUsed = checkingAccount;
                    break;
                default:
                    System.out.println("Only numbers 1-4 will work.");
                    break;
            }
        }
    }


    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        Bank bank = new Bank();
        final double  BalanceThreshold=1000;
        int choice = 0;
        final String FileLocation ="C:\\Users\\necf2\\OneDrive\\Desktop\\Folder\\Accounts.txt";

        try
        {
            bank.load(FileLocation);
        }
        catch(Exception e)
        {
            System.out.println("Failed to load accounts");
        }

        System.out.println("Welcome to Bank Account Manager");
        while (choice != 7)
        {
            System.out.println("What do you want to do?");
            System.out.println("1. Create A New Account");
            System.out.println("2. Preform Action On Existing Account");
            System.out.println("3. Delete Existing Account ");
            System.out.println("4. Display Average of Accounts");
            System.out.println("5. Display Min and Max Account Balance");
            System.out.println("6. Show Accounts With Low Balance");
            System.out.println("7. Quit");

            choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice)
            {
                case 1:
                    //create new account
                    System.out.println("What is your name");
                    String name = scanner.nextLine();
                    System.out.println("What is your gender(m/f)");
                    char gender = scanner.next().charAt(0);
                    scanner.nextLine();
                    System.out.println("What is your age?");
                    int age = scanner.nextInt();
                    scanner.nextLine();
                    System.out.println("What is your address?");
                    String address = scanner.nextLine();
                    System.out.println("What is your phone number?");
                    String phoneNumber = scanner.nextLine();

                    Person person = new Person(name,gender,age,address,phoneNumber);

                    System.out.println("What is your balance?");
                    double balance = scanner.nextDouble();
                    System.out.println("What is your withdraw limit?");
                    double withdrawLimit = scanner.nextDouble();
                    scanner.nextLine();
                    System.out.println("What is today date?");
                    String date = scanner.nextLine();
                    System.out.println("Is this a 1) Savings or 2) Checking account.");
                    int type = scanner.nextInt();

                    int accountID = bank.createID();
                    System.out.println("Your account ID is: "+accountID+" please remember this!");

                    BankAccount account = new BankAccount(person,withdrawLimit,balance,date,accountID);

                    account.setAccountType(type);
                    account.setTimesDeposited(0);
                    account.setTimesWithdrawn(0);

                    bank.addAccount(account);

                    accountMenu(account);

                    break;

                case 2:
                    //preform action on existing account
                    System.out.println("What is the account number you are looking for.");
                    int accountSearchingFor = scanner.nextInt();
                    BankAccount accountInUse = bank.findAccount(accountSearchingFor);

                    if(accountInUse!=null)
                    {
                        accountMenu(accountInUse);
                    }
                    else
                        System.out.println("Account cannot be found");

                    break;

                case 3:
                    //delete account
                    System.out.println("What is the ID of the account you want to delete?");
                    int accountSearch= scanner.nextInt();
                    boolean found=bank.deleteAccount(accountSearch);
                    if(found)
                        System.out.println("Account Deleted");
                    else System.out.println("Account Not Found.");

                    break;
                case 4:
                    //average bank account balances
                    System.out.println("The average balance is "+bank.averageBalances());
                    break;
                case 5:
                    //displays min and max balances
                    System.out.println("The largest balance is: "+bank.largestBankAccount()+
                            "\nThe smallest balance is: "+bank.smallestBankAccount());
                    break;
                case 6:
                    //displays low balance accounts
                    ArrayList<BankAccount> lowBalanceAccounts = bank.getLowBalanceAccounts(BalanceThreshold);
                    for (int pos=0;pos<lowBalanceAccounts.size();pos++)
                    {
                        BankAccount curAccount=lowBalanceAccounts.get(pos);
                        Person personName = curAccount.getAccountHolder();
                        name=personName.getName();
                        System.out.println(name +" has a balance of "+
                                curAccount.getCurrentBalance()+" and their ID is "+
                                curAccount.getAccountNumber());
                    }
                    break;
                case 7:
                    //quit
                    System.out.println("I hope you have a good day!");
                    try
                    {
                        bank.finalSave(FileLocation);
                    }
                    catch (Exception e)
                    {
                        System.out.println("Issue saving");
                    }
                    break;
                default:
                    System.out.println("Invalid command, please input only"
                            + "a number between 1 and 7.");
            }
        }
    }
}