import personlib.Person;

public class CheckingAccount extends BankAccount
{

    private int numDeposits;
    private int timesDeposited;
    private double bonusReward;

    public CheckingAccount(Person initAccountHolder, double initWithdrawLimit, double initBalance, String initDate,
                           int initAccount, double initBonus,int initNumDeposits, int initTimesDeposited)
    {
        super(initAccountHolder,initWithdrawLimit,initBalance,initDate,initAccount);

        numDeposits = initNumDeposits;
        bonusReward=initBonus;
        timesDeposited=initTimesDeposited;
    }

    @Override
    public int withdrawFunds(double withdrawAmount)
    {
       int success = super.withdrawFunds(withdrawAmount);
        if (success!=0)
            timesDeposited=0;
        return success;
    }

    @Override
    public void depositMoney (double depositAmount)
    {
        super.depositMoney(depositAmount);
        timesDeposited++;
        if(timesDeposited==numDeposits)
        {
            setCurrentBalance(getCurrentBalance()*(1+bonusReward));
            timesDeposited=0;
        }
    }


    public double getBonusReward()
    {
        return  bonusReward;
    }
    public void setBonusReward(double newBonus)
    {
        if(newBonus>0)
            bonusReward=newBonus;
    }


    public int getNumDeposits()
    {
        return numDeposits;
    }
    public void setNumDeposits(int newNumDeposits)
    {
        if(newNumDeposits>0)
            numDeposits=newNumDeposits;
    }

    public int getTimesDeposited()
    {
        return timesDeposited;
    }
    public void setTimesDeposited(int newTimesDeposited)
    {
        if(newTimesDeposited>0)
            timesDeposited=newTimesDeposited;
    }

}
