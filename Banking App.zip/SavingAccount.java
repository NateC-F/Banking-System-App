import personlib.Person;

public class SavingAccount extends BankAccount
{

    private int numDeposits;
    private int numWithdraws;
    private int timesDeposited;
    private int timesWithdrawn;
    private double bonusReward;
    private double fee;

    public SavingAccount(Person initAccountHolder, double initWithdrawLimit, double initBalance, String initDate,
                         int initAccount,double initFEE, double initBonus,int initNumDeposits, int initNumWithdraws,
                         int initTimesWithdrawn, int initTimesDeposited)
    {
        super(initAccountHolder,initWithdrawLimit,initBalance,initDate,initAccount);

        fee=initFEE;
        bonusReward=initBonus;
        numDeposits=initNumDeposits;
        numWithdraws=initNumWithdraws;
        timesDeposited=initTimesDeposited;
        timesWithdrawn=initTimesWithdrawn;
    }

    @Override
    public int withdrawFunds(double withdrawAmount)
    {
        int success = super.withdrawFunds(withdrawAmount);
        if (success!=0)
            timesDeposited=0;
        timesWithdrawn++;
        if (timesWithdrawn==numWithdraws)
            setCurrentBalance(getCurrentBalance()-getCurrentBalance()*(fee));
        return success;
    }

    @Override
    public void depositMoney (double depositAmount)
    {
        super.depositMoney(depositAmount);
        timesDeposited++;
        if(timesDeposited==numDeposits)
        {
            setCurrentBalance(getCurrentBalance()*(1+bonusReward));
            timesDeposited=0;
        }
        timesWithdrawn=0;
    }

    public double getBonusReward()
    {
        return  bonusReward;
    }
    public void setBonusReward(double newBonus)
    {
        if(newBonus>0)
            bonusReward=newBonus;
    }


    public int getNumDeposits()
    {
        return numDeposits;
    }
    public void setNumDeposits(int newNumDeposits)
    {
        if(newNumDeposits>0)
            numDeposits=newNumDeposits;
    }

    public int getNumWithdraws()
    {
        return numWithdraws;
    }
    public void setNumWithdraws(int newNumWithdraws)
    {
        if(newNumWithdraws>0)
            numWithdraws=newNumWithdraws;
    }

    public double getFee()
    {
        return fee;
    }
    public void setFee(double newFee)
    {
        if (newFee>0)
            fee=newFee;
    }



}
